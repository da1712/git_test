        <?php md_get_the_frontend_footer(); ?>

        <!-- JS Links -->
        <?php md_get_the_js_urls(); ?>

    </body>
</html>