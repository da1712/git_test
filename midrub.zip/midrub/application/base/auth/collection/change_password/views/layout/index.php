<?php if ($header) echo $header; ?>
<?php if ($body) echo $body; ?>
<?php if ($footer) echo $footer;?>