<?php
$lang["auth_change_password"] = "Change Password";