<?php
$lang["auth_page_title"] = "Page";