<?php
$lang["auth_page"] = "Page";