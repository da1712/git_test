<?php
$lang["reset"] = "Reset";
$lang["reset_password"] = "Reset Password";
$lang["reset_username_placeholder_description"] = "will be replaced with the user's username.";
$lang["reset_first_name_placeholder_description"] = "will be replaced with the user's first name.";
$lang["reset_last_name_placeholder_description"] = "will be replaced with the user's last name.";
$lang["reset_website_name_placeholder_description"] = "will be replaced with the website's name.";
$lang["reset_reset_url_placeholder_description"] = "will be replaced with the reset url.";
$lang["reset_login_url_placeholder_description"] = "will be replaced with the login url.";
$lang["reset_website_url_placeholder_description"] = "will be replaced with the website url.";