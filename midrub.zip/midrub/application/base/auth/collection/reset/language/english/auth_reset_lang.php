<?php
$lang["auth_reset_page_title"] = "Reset Password";
$lang["auth_reset_page_under_title"] = "Do you remember the password?";
$lang["auth_reset_enter_email"] = "Enter your email address ...";
$lang["auth_reset_btn"] = "Reset";
$lang["auth_reset_signin_link"] = "Sign In.";
$lang["auth_reset_details"] = "Reset Details";
$lang["auth_reset_details_title"] = "Page Title";
$lang["auth_reset_details_title_description"] = "Enter the title which will be displayed in the reset form.";
$lang["auth_reset_details_under_title"] = "Text Under Title";
$lang["auth_reset_details_under_title_description"] = "Enter the text which will be displayed in the reset form below the title.";
$lang["auth_reset_wrong_email"] = "Please enter a correct email address.";
$lang["auth_reset_email"] = "Email";