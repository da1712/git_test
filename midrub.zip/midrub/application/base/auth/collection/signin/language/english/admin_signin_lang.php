<?php
$lang["auth_signin"] = "Sign In";
$lang["auth_signin_details_title"] = "Page Title";
$lang["auth_signin_details_title_description"] = "Enter the title which will be displayed in the signin form.";
$lang["auth_signin_details_under_title"] = "Text Under Title";
$lang["auth_signin_details_under_title_description"] = "Enter the text which will be displayed in the signin form below the title.";
$lang["auth_signin_forgot_your_password"] = "Forgot password?";
$lang["auth_signin_settings_enter_image_title"] = "Enter the Image Title";
$lang["auth_signin_settings_enter_image_title_description"] = "Will be used as image's Alt. Not visible for public.";
$lang["auth_signin_slider_caption_image"] = "Slider's Image";
$lang["auth_signin_slider_caption_image_description"] = "Enter a image's url or select an image.";
$lang["auth_signin_new_photo"] = "New Photo";
$lang["auth_signin_slider"] = "Slider";
$lang["auth_signin_details"] = "Sign In Details";
$lang["auth_signin_slider"] = "Sign In Slider";
$lang["auth_signin_settings_enable"] = "Enable Slider";
$lang["auth_signin_settings_enable_description"] = "By default the slider is disabled.";