<?php
$lang["confirmation"] = "Confirmation";