<?php
$lang["media_an_error_has_occurred"] = "An error has occurred";
$lang["media_wrong_data"] = "the received data is wrong.";
$lang["media_no_free_space"] = "you don't have enough free space.";
$lang["media_no_supported_format"] = "unsupported file format.";
$lang["media_file_too_large"] = "the file is too large.";
$lang["media_file_uploaded_successfully"] = "The file has been uploaded successfully.";
$lang["media_file_not_uploaded"] = "the file has not been uploaded successfully.";
$lang["media_file_cover_missing"] = "The file can't be uploaded because the file's cover missing.";
$lang["media_user_id_missing"] = "The file can't be uploaded because a user's session missing and user_id parameter missing.";
$lang["media_allowed_extensions_missing"] = "The file can't be uploaded because the allowed_extensions parameter missing.";
$lang["media_file_not_deleted"] = "the file has not been deleted successfully.";
$lang["media_media_missing"] = "the file was not found.";
$lang["media_media_missing"] = "the file was not found.";
$lang["media_media_id_missing"] = "the media_id parameter was not found.";
$lang["media_file_was_deleted"] = "The file was deleted successfully.";