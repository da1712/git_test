<?php
$lang["theme_no_menu_found"] = "No menu found";